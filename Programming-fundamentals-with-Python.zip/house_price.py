def estimate_house_sales_price(num_of_bedrooms, sqft, neighbourhood):
    price = 0

    # In my area, the average house costs $200 per sqft
    price_per_sqft = 200

    # But some areas cost more
    if neighbourhood == "hipsterton":
        price_per_sqft = 400

    elif neighbourhood =="skid row":
        price_per_sqft = 100

    #start with a base price estimate based on how big the place is
    price = price_per_sqft*sqft

    # now adjust our estimate based on number of bedrooms
    if num_of_bedrooms == 0:
        # Studio apartments are cheap
        price = price - 20000
    else:
        #places with more bedrooms are costlier
        price = price + (num_of_bedrooms * 1000)
        
    print("The price is: "+str(price))

estimate_house_sales_price(3, 1848, "hipsterton")
