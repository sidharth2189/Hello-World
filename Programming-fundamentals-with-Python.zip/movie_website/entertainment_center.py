import media
import fresh_tomatoes

generation_war = media.Movie("Generation War",
                        "In Germany, five friends go out to war and promise each other to be back for Christmas.",
                        "https://upload.wikimedia.org/wikipedia/en/e/e8/Generation_War_2013_poster.jpg",
                        "https://www.youtube.com/watch?v=II5XRZultz0")

OneTwenty = media.Movie("120",
                        "A small army of Turkish school children set out to protect their village in the midst of First world war",
                        "https://upload.wikimedia.org/wikipedia/en/7/7e/120FilmPoster.jpg",
                        "https://www.youtube.com/watch?v=jxtsWjQRa3E")

A_death_in_gunj = media.Movie("A death in Gunj",
                        "Life for a shy young Indian student slowly falls to pieces during a family road trip",
                        "https://upload.wikimedia.org/wikipedia/en/8/86/ADeathintheGunj.jpg",
                        "https://www.youtube.com/watch?v=XliKkuxa_nA")

About_Elly = media.Movie("About Elly",
                        "A young teacher disappears during a trip, in northern Iran",
                        "https://upload.wikimedia.org/wikipedia/en/a/aa/About_elly_xlg.jpg",
                        "https://www.youtube.com/watch?v=MdqMICWhxuA")

The_Colors_of_the_Mountain = media.Movie("The colors of the mountain",
                        "A young teacher disappears during a trip, in northern Iran",
                        "https://upload.wikimedia.org/wikipedia/en/6/60/TheColorsOfTheMountains2010Poster.jpg",
                        "https://www.youtube.com/watch?v=3VzFHEcU070")

Black_Book = media.Movie("Zwart Boek",
                        "Rachel joins the Dutch resistance after her farmhouse is destroyed, while she tries to flee to South Netherlands,",
                        "https://upload.wikimedia.org/wikipedia/en/3/3e/Official_poster_Black_Book.jpg",
                        "https://www.youtube.com/watch?v=dKEDKF8iDUw")

movies = [generation_war, OneTwenty, A_death_in_gunj, About_Elly, The_Colors_of_the_Mountain, Black_Book]
#fresh_tomatoes.open_movies_page(movies)
#print(media.Movie.VALID_RATINGS)
print(media.Movie.__module__)

