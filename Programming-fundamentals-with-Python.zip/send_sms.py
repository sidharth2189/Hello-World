from twilio.rest import Client

# Your Account SID from twilio.com/console
account_sid = "AC9e81b57fc0c18422335e0edd340ef448"
# Your Auth Token from twilio.com/console
auth_token  = "07f968aa04ae7245ec239a1a2e3cd6b2"

client = Client(account_sid, auth_token)

message = client.messages.create(
    to="+917735733240", 
    from_="+12813934648",
    body="Python")

print(message.sid)
