import turtle

##def draw_square(some_turtle):
##    for i in range(1,5):
##        some_turtle.forward(100)
##        some_turtle.right(90)
##        
##def draw_art():       
##    window = turtle.Screen()
##    window.bgcolor("red")
##    # Create the turtle brad - Draws a square
##    brad = turtle.Turtle()
##    brad.shape("turtle")
##    brad.color("green")
##    brad.speed(2)
##    for i in range(1,37):
##        draw_square(brad)
##        brad.right(10)
##     
##    window.exitonclick()
##    
##draw_art()

def draw_rhombus(some_turtle):
    for i in range(1,3):
      some_turtle.forward(100)
      some_turtle.right(45)
      some_turtle.forward(100)
      some_turtle.right(135)
    
def draw_art():
    window = turtle.Screen()
    window.bgcolor("blue")
    angie = turtle.Turtle()
    angie.shape("turtle")
    angie.color("green")
    angie.speed(2)
    for i in range (1,37):
        draw_rhombus(angie)
        angie.right(10)

    angie.seth(270)
    angie.forward(300)

    window.exitonclick()

draw_art()
